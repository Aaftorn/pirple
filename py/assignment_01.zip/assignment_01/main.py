"""
This is the first assignment for the "Python is easy" Pirple course
Made by Balazs Szeidl
"""
#title of the song:
Title = "Hard Rock Halleluja"
#performer of the song:
Artist = "Lordi"
#year the song was released:
ReleaseYear = 2006
#genre of the song:
Genre = "Rock"
#duration of the song in minutes:
Duration = 4.09
#origin of the band:
Country = "Finland"
#is ther an official videoclip for this song?
HasVideo = "yes"
#album of the performer the song was released on:
Album = "The Arockalypse"
#place on Eurovision song contest (0 if did not contest):
EurovisionPlace = 1
#best place on UK Singles toplist:
UKSinglesPeakPosition = 25

print(Title)
print(Artist)
print(ReleaseYear)
print(Genre)
print(Duration)
print(Country)
print(HasVideo)
print(Album)
print(EurovisionPlace)
print(UKSinglesPeakPosition)