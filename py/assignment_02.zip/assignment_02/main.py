"""
This is the second assignment for the "Python is easy" Pirple course
Made by Balazs Szeidl
"""
#title of the song:
def Title():
	return "Hard Rock Halleluja"
#performer of the song:
def Artist():
	return "Lordi"
#duration of the song in minutes:
def Duration():
	return 4.09
#is there an official videoclip for this song?
def HasVideo():
	return True

print(Title())
print(Artist())
print(Duration())
print(HasVideo())
